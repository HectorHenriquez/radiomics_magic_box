const $ = selector => document.querySelector(selector);
const imageInput=$('#image'),maskInput=$('#mask'),patientIdInput=$('#patient-id');
const geometryMessage=$('#geometry-message'),previewNote=$('#preview-note');
const run=$('#run'),download=$('#download'),status=$('#status');
const normalization=$('#normalization'),resample=$('#resample'),interpolation=$('#interpolation'),binWidth=$('#bin-width');
const resultSection=$('#result-section'),resultBody=$('#result-body'),resultCount=$('#result-count');
const imageTypeFilter=$('#image-type-filter'),familyFilter=$('#family-filter'),featureSearch=$('#feature-search');
const FAMILY_LABELS={firstorder:'Primer orden',shape:'Forma',glcm:'GLCM',glrlm:'GLRLM',glszm:'GLSZM',gldm:'GLDM',ngtdm:'NGTDM',diagnostic:'Diagnóstico'};
let previewVersion=0,geometryReady=false,busy=false,allFeatures=[];

const suggestedId = name => name.replace(/\.nrrd$/i,'').replace(/(?:_chest_ct)?_image$/i,'');
const updateRun = () => {run.disabled=busy||!geometryReady;};
const setGeometry = (message,tone='') => {geometryMessage.className=`geometry ${tone}`;geometryMessage.textContent=message;};
const resetPreview = () => {
  for(const [canvas,placeholder] of [['#image-canvas','#image-placeholder'],['#overlay-canvas','#overlay-placeholder']]){
    $(canvas).style.display='none';$(placeholder).hidden=false;
  }
  previewNote.textContent='Se mostrará el corte positivo más cercano al centro de la máscara. Ventana fija: nivel 40 HU, ancho 400 HU.';
};
const clearResults = () => {allFeatures=[];resultSection.hidden=true;download.hidden=true;resultBody.replaceChildren();};
const draw = (selector,bytes,width,height) => {
  const canvas=$(selector);canvas.width=width;canvas.height=height;
  canvas.getContext('2d').putImageData(new ImageData(bytes,width,height),0,0);
  canvas.style.display='block';
  $(selector==='#image-canvas'?'#image-placeholder':'#overlay-placeholder').hidden=true;
};
const runWorker = (payload,image,mask) => new Promise((resolve,reject) => {
  const worker=new Worker('./worker.mjs',{type:'module'});
  worker.onmessage=event=>{worker.terminate();resolve(event.data);};
  worker.onerror=error=>{worker.terminate();reject(Error(error.message||'Error en el trabajador del navegador'));};
  worker.postMessage({...payload,image,mask},[image,mask]);
});

async function inspectFiles() {
  const version=++previewVersion;
  geometryReady=false;updateRun();clearResults();resetPreview();status.textContent='';
  if(!imageInput.files[0]||!maskInput.files[0]){
    setGeometry('Selecciona imagen y máscara para revisar la geometría.');
    return;
  }
  setGeometry('Leyendo archivos y comprobando dimensiones, orientación y origen…');
  try {
    const [image,mask]=await Promise.all([imageInput.files[0].arrayBuffer(),maskInput.files[0].arrayBuffer()]);
    if(version!==previewVersion)return;
    const response=await runWorker({action:'preview'},image,mask);
    if(version!==previewVersion)return;
    if(response.error)throw Error(response.error);
    if(!response.geometry?.ok){
      setGeometry(`Aviso de geometría: ${response.geometry?.issues?.join(' ')||'Los archivos no son compatibles.'}`,'error');
      return;
    }
    if(response.imageRgba){
      draw('#image-canvas',response.imageRgba,response.width,response.height);
      draw('#overlay-canvas',response.overlayRgba,response.width,response.height);
      previewNote.textContent=`Corte axial ${response.slice+1} de ${response.geometry.imageSize[2]} · centro positivo (x ${response.center[0].toFixed(1)}, y ${response.center[1].toFixed(1)}, z ${response.center[2].toFixed(1)}) · ventana 40/400 HU.`;
    }
    const dimensions=response.geometry.imageSize.join('×');
    const spacing=response.geometry.spacing.map(value=>value.toFixed(3)).join('×');
    const details=`Geometría compatible: ${dimensions} vóxeles; tamaño ${spacing} mm. Máscara: ${response.positive||0} vóxeles positivos.`;
    if(response.warning){
      setGeometry(`${details} ${response.warning}`,'warning');
    }else if(response.positive!==response.labelOne){
      setGeometry(`${details} La vista muestra todas las etiquetas positivas; la extracción usa la etiqueta 1 (${response.labelOne} vóxeles).`,'warning');
    }else setGeometry(details,'ok');
    geometryReady=Boolean(response.ok);updateRun();
  }catch(error){
    if(version!==previewVersion)return;
    setGeometry(`No se pudo revisar el caso: ${error.message}`,'error');
  }
}

imageInput.addEventListener('change',()=>{
  if(imageInput.files[0])patientIdInput.value=suggestedId(imageInput.files[0].name);
  inspectFiles();
});
maskInput.addEventListener('change',inspectFiles);
normalization.addEventListener('change',()=>{binWidth.value=normalization.value==='minmax'?'0.05':'75';});

const featureParts = name => {
  if(name==='VoxelCount')return {imageType:'diagnostic',family:'diagnostic'};
  const underscore=name.indexOf('_');
  const imageType=name.slice(0,underscore);
  return {imageType,family:name.slice(underscore+1).split('_')[0]};
};
const imageTypeLabel = value => {
  if(value==='original')return 'Original';
  if(value==='diagnostic')return 'Diagnóstico';
  if(value.startsWith('wavelet-'))return value.replace('wavelet-','Wavelet ');
  const sigma=value.match(/^log-sigma-(.+)-mm-3D$/);
  if(sigma)return `LoG σ ${sigma[1].replaceAll('-','.')} mm`;
  return value;
};
function populateSelect(select,values,labels) {
  select.replaceChildren(new Option('Todas','all'));
  for(const value of values)select.add(new Option(labels(value),value));
}
function renderResults() {
  const type=imageTypeFilter.value,family=familyFilter.value,query=featureSearch.value.trim().toLowerCase();
  const fragment=document.createDocumentFragment();let shown=0;
  for(const [name,value,parts] of allFeatures) {
    if(type!=='all'&&parts.imageType!==type||family!=='all'&&parts.family!==family||query&&!name.toLowerCase().includes(query))continue;
    const row=document.createElement('tr');
    row.insertCell().textContent=name;
    row.insertCell().textContent=String(value);
    fragment.append(row);shown++;
  }
  resultBody.replaceChildren(fragment);
  resultCount.textContent=`${shown} de ${allFeatures.length} valores`;
}
for(const control of [imageTypeFilter,familyFilter,featureSearch])control.addEventListener(control===featureSearch?'input':'change',renderResults);

run.addEventListener('click',async()=>{
  if(!geometryReady||!imageInput.files[0]||!maskInput.files[0])return;
  const version=previewVersion;
  const spacing='xyz'.split('').map(axis=>Number($(`#spacing-${axis}`).value));
  const filters=[...document.querySelectorAll('input[name="filter"]:checked')].map(input=>input.value);
  const logSigmas=$('#log-sigmas').value.split(',').map(value=>Number(value.trim()));
  const width=Number(binWidth.value);
  if(!(width>0)){status.textContent='BinWidth debe ser positivo.';return;}
  if(resample.checked&&spacing.some(value=>!(value>0))){status.textContent='El tamaño de vóxel debe ser positivo en los tres ejes.';return;}
  if(filters.includes('log')&&(!logSigmas.length||logSigmas.some(value=>!(value>0)))){
    status.textContent='Ingresa uno o más valores sigma positivos, separados por coma.';return;
  }
  busy=true;updateRun();clearResults();status.textContent='Leyendo archivos locales…';
  try{
    const [image,mask]=await Promise.all([imageInput.files[0].arrayBuffer(),maskInput.files[0].arrayBuffer()]);
    if(version!==previewVersion)return;
    status.textContent='Calculando características en segundo plano…';
    const response=await runWorker({action:'extract',normalization:normalization.value,
      resample:resample.checked,spacing,interpolation:interpolation.value,binWidth:width,filters,logSigmas},image,mask);
    if(version!==previewVersion)return;
    if(!response.ok)throw Error(response.error);
    allFeatures=Object.entries(response.features).map(([name,value])=>[name,value,featureParts(name)]);
    const imageTypes=[...new Set(allFeatures.map(([, ,parts])=>parts.imageType))]
      .sort((a,b)=>a==='original'?-1:b==='original'?1:a==='diagnostic'?1:b==='diagnostic'?-1:a.localeCompare(b));
    const familyOrder=['firstorder','shape','glcm','glrlm','glszm','gldm','ngtdm','diagnostic'];
    const families=[...new Set(allFeatures.map(([, ,parts])=>parts.family))]
      .sort((a,b)=>familyOrder.indexOf(a)-familyOrder.indexOf(b));
    populateSelect(imageTypeFilter,imageTypes,imageTypeLabel);
    populateSelect(familyFilter,families,value=>FAMILY_LABELS[value]||value);
    featureSearch.value='';renderResults();
    resultSection.hidden=false;download.hidden=false;
    status.textContent=`Cálculo completo: ${allFeatures.length} valores.`;
  }catch(error){if(version===previewVersion)status.textContent=`Error: ${error.message}`;}
  finally{busy=false;updateRun();}
});

download.addEventListener('click',()=>{
  if(!allFeatures.length)return;
  const patientId=patientIdInput.value.trim()||suggestedId(imageInput.files[0].name);
  const cell=value=>`"${String(value).replaceAll('"','""')}"`;
  const names=allFeatures.map(([name])=>name);
  const csv=[['patient_id',...names].map(cell).join(','),
    [patientId,...allFeatures.map(([,value])=>value)].map(cell).join(',')].join('\n');
  const url=URL.createObjectURL(new Blob(['\uFEFF',csv],{type:'text/csv;charset=utf-8'}));
  const link=document.createElement('a');link.href=url;link.download=`${patientId.replace(/[^a-zA-Z0-9._-]/g,'_')}_radiomics.csv`;link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
});
